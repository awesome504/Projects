import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DataNodeVisitor implements visitor {
    private List<Node> dataStatements;

    // Constructor: Initializes the list to store collected data statements
    public DataNodeVisitor() {
        this.dataStatements = new ArrayList<>();
    }

    
    public Collection<Node> getDataStatements() {
        return dataStatements;//returns collected data statements
    }

    //loop termination conditions is validated
    public void visitNextNode(NextNode nextNode) {
        System.out.println("Visited a NextNode: " + nextNode.getLineNumber());
    }

    //end statements are handled accordinghly to terminate programs
    public void visitEndNode(EndNode endNode) {
        System.out.println("Visited an EndNode: " + endNode.getLineNumber()); 
    }

    //if statements are handled branching takes place
    public void visitIfNode(IfNode ifNode) {
        System.out.println("Visited an IfNode: " + ifNode.getLineNumber());
    }

    //gosub is handled
    public void visitGosubNode(GosubNode gosubNode) {
        System.out.println("Visited a GosubNode: " + gosubNode.getLineNumber());
    }

    //the return statements are handles
    public void visitReturnNode(ReturnNode returnNode) {
        System.out.println("Visited a ReturnNode: " + returnNode.getLineNumber());
    }

    //for npde statements are handles
    public void visitForNode(ForNode forNode) {
        System.out.println("Visited a ForNode: " + forNode.getLineNumber());
    }
}
