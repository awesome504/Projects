public class Node {
    public  String toString() {
		return null;
	}

	public Node evaluate() {
		// TODO Auto-generated method stub
		return null;
	}

	protected Object getType() {
		return null;
	}

	public Node getLeft() {
		// TODO Auto-generated method stub
		return null;
	}
}