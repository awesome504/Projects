public  class ExpressionNode extends Node {
    // Since expressions generally have values, let's add a method for evaluation
     // Value could be a class representing different data types

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node evaluate() {
		// TODO Auto-generated method stub
		return null;
	}
}
