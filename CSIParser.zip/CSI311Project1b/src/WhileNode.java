public class WhileNode extends StatementNode { 
    private BooleanExpression condition;
    private StatementNode body;

    // Constructor
    public WhileNode(BooleanExpression condition, StatementNode body) {
        super(condition.getLineNumber()); // Assuming you want to track line numbers
        this.condition = condition;
        this.body = body;
    }

    // Getters (if needed)
    public BooleanExpression getCondition() { return condition; }
    public StatementNode getBody() { return body; } 

    // The crucial 'evaluate' method 
    @Override
    public void evaluate() {
        while (condition.evaluate()) { // Evaluate the condition 
            body.evaluate();           // Execute the body if true
            // Potential updates to variables within the loop body
        } 
    }
}
