import java.io.IOException;
import java.nio.file.*;
import java.util.Arrays;

public class CodeHandler {
private int ind; //variable for index
private String docx;//variable for document
public CodeHandler(String filename) {
try {
Path filePath = Paths.get(filename);// THIS statement creates a path object for thefilepath
this.docx = new String(Files.readAllBytes(filePath)); //Document is filled with content within the file fill,
this.ind = 0; } catch ( Exception e ) {// the set index is zero
e.printStackTrace();
System.err.println("There is an error in trying to read the file:" + e.getMessage());//print statementennt if the file cannot be read
}
}



public CodeHandler(Path path) {} //The code handler construct accepts a path object 
public char look (int i) {//dcument material is used  from the file path
	if (ind +i<docx.length()) {//wants to see if the i charcters that are forqard are in bounds of document
		return docx.charAt(ind +i);//increments the characters if if document is a specific length
    }
return '\0';
//this returns a character at the end of document.
}
public String lookString (int i) { //checks for i characters fromthe x moving forward
	if (ind+i<= docx.length()) { //if it is within bounds the substring from the curent index i is being returned forward
		return docx.substring(ind,ind+i);}
	return docx.substring(ind); //the substring for the document is returned 
	}


public char getChar(){
if(!isDone()) {//this checks to see if the end of the document has been reached
		char currentChar = docx.charAt(ind);//if this isnt done than the current characters are gotten as well
		ind +=1; //nect character uis moved to
		return currentChar;}//currentcharcter is returned
return '\0';}
public void eat (int i) { //index is moved i times forward
	ind +=i;}
public boolean isDone() { //this checks to see if index come to reach or go past the document length
	return ind >= docx.length(); //this returns the document
}
public String leftover() {//return substring of the document
	return docx.substring(ind);//return substring of the document
}
}

