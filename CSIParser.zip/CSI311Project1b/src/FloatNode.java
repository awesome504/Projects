public class FloatNode extends Node {
    private final float value;
    public FloatNode(float value) {//this constructor initialize with a float value
        this.value = value;
    }
    public float getValue() {//this method gets the float value for the node
        return value;//This is return value
    }
    @Override
    public String toString() {
        return String.valueOf(value);//This converts the float value too a string and returns
    }}
