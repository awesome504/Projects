import java.util.LinkedList;

public class DataNode extends StatementNode {
    private final LinkedList<Node> values;
    public DataNode(int lineNumber, LinkedList<Node> values) {
        super(lineNumber);
        this.values = new LinkedList<>(values); 
    }
        public LinkedList<Node> getValues() {// Getter for values
        return new LinkedList<>(values); 
    }
    @Override // Override toString method
    public String toString() {
        StringBuilder representation = new StringBuilder("DATA ");
        for (Node value : values){
            representation.append(value.toString()).append(", ");
        }
        if (!values.isEmpty()) { 
            representation.delete(representation.length() - 2, representation.length());   
        }return representation.toString();}

    @Override
    public void evaluate() {
        Interpreter interpreter = Interpreter.getInstance();   // Obtain an instance of your Interpreter
        interpreter.variableStorage.addAll(values); // Store the values in your interpreter's data storage mechanism:
    }}

