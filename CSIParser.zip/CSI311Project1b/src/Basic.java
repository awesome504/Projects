import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class Basic {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java Basic <filename>");
            System.exit(1);
        }

        String filename = args[0];
        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            for (String line : lines) {
                Lexer lexer = new Lexer();
                LinkedList<Token> tokens = lexer.lex(line); 

                // this checks for the parser
                Parser parser = new Parser(tokens); 
                Node parseTree = parser.parse(); 
                
                System.out.println("This is the parse tree: \n" + parseTree.toString()); //
                System.out.println("This is the lexing line: " + line);
                
                Interpreter interpreter = new Interpreter();
                interpreter.interpret(parseTree);
                
            }
        } catch (IOException e) {
            System.err.println("There is an error reading the file " + e.getMessage()); //error message
            System.exit(1);}}}
