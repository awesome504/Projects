public class LabeledStatementNode extends StatementNode {
    private final String label;
    private final StatementNode statement;

    public LabeledStatementNode(int lineNumber, String label, StatementNode statement) {
        super(lineNumber);
        this.label = label;
        this.statement = statement;
    }

    public String getLabel() {
        return label;
    }

    public StatementNode getStatement() {
        return statement;
    }

    @Override
    public String toString() {
        return "Label: " + label + ", Statement: " + statement.toString();
    }

    @Override
    public void evaluate() {
        // Evaluate the contained statement
        statement.evaluate();
    }
}
