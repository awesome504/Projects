public class NextNode extends StatementNode {
    private String loopVariable;
    private int step;
    private int finalValue;
    private String forLabel; //assuming the string label 

    public NextNode(int lineNumber) {
        super(lineNumber);
    }

    public String getLoopVariable() {//get loopvariable method
        return loopVariable; }

    public int getStep() {
        return step;}

    public int getFinalValue() {
        return finalValue;}

    public String getForLabel() {
        return forLabel;}

    public void setLoopVariable(String loopVariable) {
        this.loopVariable = loopVariable;
    }

    public void setStep(int step){
        this.step = step;}

    public void setFinalValue(int finalValue) {
        this.finalValue = finalValue;
    }

    public void setForLabel(String forLabel) {
        this.forLabel = forLabel;
    }
    @Override
    public void accept(DataNodeVisitor visitor) {//data node visitor method implements interface
        visitor.visitNextNode(this);
    }


    @Override
    public void evaluate() {
        int currentValue = (int) Interpreter.getInstance().getVariable(loopVariable); // Get the current value of the loop variable

        
        currentValue += step;//the loop grows by 1 step each time

        // Set the updated value back to the interpreter
        Interpreter.getInstance().setVariable(loopVariable, currentValue);
        if (currentValue <= finalValue) {//should the loop continue
            jumpToLoopStart(forLabel);     // Continue the loop
        } else {
            exitLoop();//exit loop
        }}

    protected void jumpToLoopStart(String forLabel) {
        //this logic is for jump to start loop
    	StatementNode startOfLoop = Interpreter.getInstance().getLabelMap().get((String) forLabel);
        if (startOfLoop != null && startOfLoop instanceof ForNode) {
            // Execute the body of the loop again
            startOfLoop.evaluate();
        } else {
            throw new RuntimeException("Invalid FOR loop label: " + forLabel); } }

    protected void exitLoop() {//this allows loop to exit
    	}
    }



