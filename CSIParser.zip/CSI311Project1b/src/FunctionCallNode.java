import java.util.HashMap;
import java.util.LinkedList;
import java.util.function.Function;

public class FunctionCallNode extends ExpressionNode {
    private String functionName;
    private LinkedList<ExpressionNode> parameters;

    public FunctionCallNode(String functionName, LinkedList<ExpressionNode> parameters) {
        this.functionName = functionName;
        this.parameters = parameters;
    }

    public String getFunctionName() {
        return functionName;
    }

    public LinkedList<ExpressionNode> getParameters() {
        return parameters;
    }

    @Override
    public Node evaluate() {
        HashMap<String, Function<LinkedList<Node>, Node>> functionEnvironment = new HashMap<>();
        
        // Populate functionEnvironment with function definitions 

        Function<LinkedList<Node>, Node> function = functionEnvironment.get(functionName);
        if (function == null) {
            throw new RuntimeException("Undefined function: " + functionName);
        }

        // Parameter Evaluation
        LinkedList<Node> evaluatedParams = new LinkedList<>();
        for (ExpressionNode parameter : parameters) {
            Node evaluatedParam = parameter.evaluate();
            evaluatedParams.add(evaluatedParam);
        }

        // Function Execution
        return function.apply(evaluatedParams);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(functionName + "(");
        boolean isFirst = true;
        for (ExpressionNode param : parameters) {
            if (!isFirst) {
                sb.append(", ");
            }
            sb.append(param.toString());
            isFirst = false;
        }
        sb.append(")");
        return sb.toString();
    }
}

