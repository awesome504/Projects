public class StatementNode {
    private int lineNumber;
    private StatementNode next;

    public StatementNode(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setNext(StatementNode next) {
        this.next = next;
    }

    public StatementNode getNext() {
        return next;
    }

    public void evaluate() {
        // Method to evaluate the statement
    }

    public void accept(DataNodeVisitor visitor) {
        // Method to accept a visitor
    }

    public StatementNode[] getStatements() {
        // Method to get nested statements
        return null;
    }

    // Method to build next pointers for nested statements
    public void buildNextPointers(StatementNode rootNode) {
        StatementNode current = rootNode;
        StatementNode previous = null;

        while (current != null) {
            if (previous != null) {
                previous.setNext(current);
            }

            if (current instanceof StatementNode) {
                StatementNode[] statements = current.getStatements();
                if (statements.length > 0) {
                    buildNextPointers(statements[0]); // Recursively traverse nested statements
                }
            }

            previous = current;
            current = current.getNext(); // Move to the next statement
        }
    }
}

