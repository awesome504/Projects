public class IfNode extends StatementNode {
    private BooleanExpression condition;
    private StatementNode thenStatement;
    private StatementNode elseStatement; // Optional

    public IfNode(BooleanExpression condition, StatementNode thenStatement, StatementNode elseStatement) {
        super(condition.getLineNumber()); // Assuming you want to track line numbers
        this.condition = condition;
        this.thenStatement = thenStatement;
        this.elseStatement = elseStatement;
    }

 
    public BooleanExpression getCondition() { return condition; }// Extract the initial value from the initialization
    public StatementNode getThenStatement() { return thenStatement; }
    public StatementNode getElseStatement() { return elseStatement; }

    @Override
    public void evaluate() {
        if (condition.evaluate()) { // Evaluate the condition
            thenStatement.evaluate();  // This executes the then brach if it is true
        } else if (elseStatement != null) { 
            elseStatement.evaluate();  // the else branchh will excute if false
        }  }

	public String getLabel() {
		return null;}}

