import org.junit.Test;
import org.junit.Assert;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;

public class CodeHandlerTest {

    @Test
    public void testCodeHandlerReadsFile() {
        String filename = "test.txt";
        CodeHandler codeHandler = new CodeHandler(filename);

        Assert.assertEquals("Hello, World!", codeHandler.leftover());
    }

    @Test
    public void testCodeHandlerlook() {
        String filename = "test.txt";
        CodeHandler codeHandler = new CodeHandler(filename);

        Assert.assertEquals('H', codeHandler.look(0));
        Assert.assertEquals('e', codeHandler.look(1));
        Assert.assertEquals('l', codeHandler.look(2));
    }

    @Test
    public void testCodeHandlerGetChar() {
        String filename = "test.txt";
        CodeHandler codeHandler = new CodeHandler(filename);

        Assert.assertEquals('H', codeHandler.getChar());
        Assert.assertEquals('e', codeHandler.getChar());
        Assert.assertEquals('l', codeHandler.getChar());
    }

    @Test
    public void testCodeHandlerIsDone() {
        String filename = "test.txt";
        CodeHandler codeHandler = new CodeHandler(filename);

        Assert.assertFalse(codeHandler.isDone());

        while (!codeHandler.isDone()) {
            codeHandler.getChar();
        }

        Assert.assertTrue(codeHandler.isDone());
    }
}


