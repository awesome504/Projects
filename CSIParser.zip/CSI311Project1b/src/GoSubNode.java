import java.util.Stack;
import java.util.HashMap; 

class GosubNode extends StatementNode {
    private HashMap<String, Integer> labelMap = new HashMap<>(); 
    private Stack<Integer> callStack = new Stack<>(); 
    private String targetLabel; 

    public GosubNode(int lineNumber) { //Go sub line numb er method 
        super(lineNumber);
    }
    public void setTargetLabel(String targetLabel) { // Renamed the method
        this.targetLabel = targetLabel;
    }

    public String getTargetLabel() {
        return targetLabel;}

    @Override 
    public void evaluate() {
        callStack.push(getLineNumber() + 1); // Push the next line number onto the call stack

        int targetLineNumber = labelMap.getOrDefault(targetLabel, -1);
        if (targetLineNumber == -1) {
            System.err.println("Error: Label '" + targetLabel + "' not found.");
            return; // Exit the method if label not found
        }

        // Set the current line number in the interpreter
        Interpreter.setCurrentLineNumber(targetLineNumber);
    }
    public String getLabel() {
        return targetLabel;}}
