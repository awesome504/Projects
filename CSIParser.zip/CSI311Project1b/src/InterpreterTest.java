import org.junit.Test;
import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import static org.junit.Assert.*;
	 import org.junit.Test;

	 public class InterpreterTest {

	     @Test
	     public void testRandom() {

	         for (int i = 0; i < 1000; i++) {
	             int min = 1;
	             int max = 10;
	             int randomValue = Interpreter.random(min, max);
	             assertTrue(randomValue >= min && randomValue <= max);
	         }
	     }

	     @Test
	     public void testLEFT$() {
	         assertEquals("Hello", Interpreter.LEFT$("Hello World", 5));
	         assertEquals("", Interpreter.LEFT$("Hello", 0));
	         assertEquals("Hello World", Interpreter.LEFT$("Hello World", 15));
	     }

	     @Test
	     public void testRIGHT$() {
	         assertEquals("World", Interpreter.RIGHT$("Hello World", 5));
	         assertEquals("", Interpreter.RIGHT$("Hello", 0));
	         assertEquals("Hello World", Interpreter.RIGHT$("Hello World", 15));
	     }



	     @Test
	     public void testMID$() {
	         assertEquals("ello", Interpreter.MID$("Hello World", 2, 4));
	         assertEquals("Hello", Interpreter.MID$("Hello", 1, 5)); // Requested count is greater than string length
	         assertEquals("", Interpreter.MID$("Hello World", 15, 5)); // Start index exceeds string length
	         assertEquals("", Interpreter.MID$("", 1, 5)); // Empty input string
	         assertEquals("", Interpreter.MID$("Hello", 0, 5)); // Negative start index
	         assertEquals("", Interpreter.MID$("Hello", 1, 0)); // Non-positive count
	         assertEquals("", Interpreter.MID$(null, 1, 5)); // Null input string
	     }
	    

	     @Test
	     public void testNUM$() {
	         // Test numeric values
	         assertEquals("123", Interpreter.NUM$(123));
	         assertEquals("45.67", Interpreter.NUM$(45.67f));
	         assertEquals("89.0", Interpreter.NUM$(89.0d));

	         // Test string representations of numbers
	         assertEquals("123", Interpreter.NUM$("123"));
	         assertEquals("45.67", Interpreter.NUM$("45.67"));
	         assertEquals("-89.0", Interpreter.NUM$("-89.0"));

	         
	         try {
	             Interpreter.NUM$("abc");
	             // If the above line doesn't throw an exception, the test fails
	             assertEquals("Should have thrown NumberFormatException", true, false);
	         } catch (RuntimeException e) {
	             assertEquals("The  numeric string for NUM$ conversion is not valid: abc", e.getMessage());
	         }

	         // Test unsupported data type
	         try {
	             Interpreter.NUM$(true);
	             // If the above line doesn't throw an exception, the test fails
	             assertEquals("Should have thrown RuntimeException", true, false);
	         } catch (RuntimeException e) {
	             assertEquals("This data type is Unsupported for NUM$ conversion: java.lang.Boolean", e.getMessage());
	         }}

	     @Test
	     public void testVAL() {
	         assertEquals(10.0, Interpreter.VAL("10"), 0.001);
	         assertEquals(5.5, Interpreter.VAL("5.5"), 0.001);
	         assertEquals(123.0, Interpreter.VAL("123"), 0.001);
	         assertEquals(3.14, Interpreter.VAL("3.14"), 0.001);
	         
	         // Test for invalid conversions
	         try {
	             Interpreter.VAL("abc");
	             fail("Expected RuntimeException for invalid conversion");
	         } catch (RuntimeException e) {
	             // Test passed
	         }
	     }

	     @Test
	     public void testVALPERCENT() {
	         assertEquals(10, Interpreter.VALPERCENT("10"));
	         assertEquals(55, Interpreter.VALPERCENT("55"));
	         assertEquals(123, Interpreter.VALPERCENT("123"));
	         
	         // Test for invalid conversions
	         try {
	             Interpreter.VALPERCENT("abc");
	             fail("Expected RuntimeException for invalid conversion");
	         } catch (RuntimeException e) {
	             
	         }
	     }
	 

	     @Test
	     public void testToggleTestMode() {
	         Interpreter interpreter = new Interpreter();
	         assertFalse(interpreter.isTestMode()); // Initially, test mode should be off

	         interpreter.toggleTestMode();
	         assertTrue(interpreter.isTestMode()); // After toggling, test mode should be on

	         interpreter.toggleTestMode();
	         assertFalse(interpreter.isTestMode()); // Toggling again, test mode should be off
	     }

	     @Test
	     public void testSetAndGetInputQueue() {
	         Interpreter interpreter = new Interpreter();
	         Queue<String> inputQueue = new LinkedList<>();
	         inputQueue.add("Input 1");
	         inputQueue.add("Input 2");

	         interpreter.setInputQueue(inputQueue);
	         assertEquals(inputQueue, interpreter.getOutputQueue());
	     }

	     @Test
	     public void testGetOutputQueue() {
	         Interpreter interpreter = new Interpreter();
	         assertNotNull(interpreter.getOutputQueue());
	         assertTrue(interpreter.getOutputQueue().isEmpty());
	     }

	     @Test
	     public void testSetAndGetTestInput() {
	         Interpreter interpreter = new Interpreter();
	         List<String> testInput = new LinkedList<>();
	         testInput.add("Test Input 1");
	         testInput.add("Test Input 2");

	         interpreter.setTestInput(testInput);
	         assertEquals(testInput, interpreter.getTestOutput());
	     }

	     @Test
	     public void testGetTestOutput() {
	         Interpreter interpreter = new Interpreter();
	         assertNotNull(interpreter.getTestOutput());
	         assertTrue(interpreter.getTestOutput().isEmpty());
	     }

	     @Test
	     public void testClearOutputQueue() {
	         Interpreter interpreter = new Interpreter();
	         interpreter.getOutputQueue().add("Output 1");
	         interpreter.getOutputQueue().add("Output 2");

	         interpreter.clearOutputQueue();
	         assertTrue(interpreter.getOutputQueue().isEmpty());
	     }

	     @Test
	     public void testInput() {
	         Interpreter interpreter = new Interpreter();
	         interpreter.toggleTestMode(); // Enable test mode

	         interpreter.input("Test Input 1");
	         interpreter.input("Test Input 2");

	         List<String> testInput = interpreter.getTestOutput();
	         assertEquals("Test Input 1", testInput.get(0));
	         assertEquals("Test Input 2", testInput.get(1));
	     }

	     @Test
	     public void testPrint() {
	         Interpreter interpreter = new Interpreter();
	         interpreter.toggleTestMode(); // Enable test mode

	         interpreter.print("Test Output 1");
	         interpreter.print("Test Output 2");

	         List<String> testOutput = interpreter.getTestOutput();
	         assertEquals("Test Output 1", testOutput.get(0));
	         assertEquals("Test Output 2", testOutput.get(1));
	     }
	     @Test
	     public void testInterpret() {
	         Interpreter interpreter = new Interpreter();

	         Node integerNode = new IntegerNode(10);
	         assertEquals(10, interpreter.interpret(integerNode));

	         Node floatNode = new FloatNode(5.5f);
	         assertEquals(5.5f, interpreter.interpret(floatNode));

	         Node stringNode = new StringNode("Hello");
	         assertEquals("Hello", interpreter.interpret(stringNode));
	     }
	     @Test
	     public void testBuildStatementLinkedList() {
	         // Create a linked list of statement nodes
	         StatementNode node1 = new StatementNode(0);
	         StatementNode node2 = new StatementNode(0);
	         StatementNode node3 = new StatementNode(0);

	         node1.setNext(node2);
	         node2.setNext(node3);

	         Interpreter interpreter = new Interpreter();
	         interpreter.buildStatementLinkedList(node1);

	         // Verify that the next pointers are correctly set
	         assertEquals(node2, node1.getNext());
	         assertEquals(node3, node2.getNext());
	         assertNull(node3.getNext()); // Last node should have a null next pointer
	     }

	     @Test
	     public void testEvaluateInteger() {
	         Interpreter interpreter = new Interpreter();

	         Node integerNode = new IntegerNode(10);
	         assertEquals(10, interpreter.evaluateInt(integerNode));

	         // Add more test cases as needed
	     }

	     @Test
	     public void testEvaluateFloat() {
	         Interpreter interpreter = new Interpreter();

	         Node floatNode = new FloatNode(5.5f);
	         assertEquals(5.5f, interpreter.evaluateFloat(floatNode), 0.001);

	     
	     }

	     @Test
	     public void testEvaluateString() {
	         Interpreter interpreter = new Interpreter();

	         Node stringNode = new StringNode("Hello");
	         assertEquals("Hello", interpreter.evaluateString(stringNode));

	        
	     }
	 


	@Test
	public void testDataOptimization() {
	    Interpreter interpreter = new Interpreter();
	    String basicProgram = "10 DATA 42, 3.14, \"Hello\"";
	    interpreter.preprocess(buildASTNode(basicProgram)); 

	    assertEquals(3, interpreter.variableStorage.size()); // Adjust if using a different structure
	    assertEquals(42, interpreter.variableStorage.get(0));  
	    assertEquals(3.14, interpreter.variableStorage.get(1)); 
	    assertEquals("Hello", interpreter.variableStorage.get(2));  
	}

	private StatementNode buildASTNode(String basicProgram) {
	   
	    String[] lines = basicProgram.split("\n");

	    List<StatementNode> statementNodes = new LinkedList<>();

	  
	    for (String line : lines) {
	        
	        StatementNode statementNode = parseStatement(line);

	        statementNodes.add(statementNode);
	    }

	    
	    return null;
	}

	
	private StatementNode parseStatement(String line) {
		return null;
	   
	}

@Test
public void testDuplicateLabel() {
    String basicProgram = "10 LABEL MYLABEL\n20 LABEL MYLABEL";  
    Interpreter interpreter = new Interpreter();
    assertThrows(RuntimeException.class, () -> interpreter.preprocess(buildASTNode(basicProgram)));
}
}