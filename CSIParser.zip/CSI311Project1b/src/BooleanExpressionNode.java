class BooleanExpression {
    private String operator; // e.g., >, >=, <, <=, ==, !=
    private Object operand1; 
    private Object operand2; 

    // Constructor
    public BooleanExpression(String operator, Object operand1, Object operand2) {
        this.operator = operator;
        this.operand1 = operand1;
        this.operand2 = operand2;
    }

    // Getters (add these if needed) 
    public String getOperator() { return operator; }
    public Object getOperand1() { return operand1;} 
    public Object getOperand2() { return operand2; } 

    //  evaluate() method (we'll discuss this below)
    public boolean evaluate() {
        if (operand1 instanceof Integer && operand2 instanceof Integer) {
            int val1 = (Integer) operand1;
            int val2 = (Integer) operand2;

            switch (operator) {
                case ">":  return val1 > val2;
                case ">=": return val1 >= val2;
                // ... cases for other operators
                default: 
                   throw new IllegalArgumentException("Invalid operator"); 
            }

        } else if (operand1 instanceof String && operand2 instanceof String) {
            // Implement string comparison logic here
        } else {
            // Handle mismatch or unsupported types
            throw new IllegalArgumentException("Unsupported operand types"); 
        }
		return false;
    }

	public int getLineNumber() {
		// TODO Auto-generated method stub
		return 0;
	}}