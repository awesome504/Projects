import java.util.LinkedList;
import java.util.Scanner;

public class ReadNode extends StatementNode {
    private final LinkedList<VariableNode> variables;

    public ReadNode(int lineNumber, LinkedList<VariableNode> variables) {
        super(lineNumber);
        this.variables = variables;//this i the readnode constructor
    }

    public LinkedList<VariableNode> getVariables() {
        return variables; //this is a getter for variables
    }

    public void evaluate(Interpreter interpret) {
        for (VariableNode variable : variables) {
            String varName = variable.getName();
            Object value = null;

            // Retrieve the value based on the variable's type
            if (variable.getType() == Interpreter.ValueType.INTEGER) {
                value = readIntegerInput();
            } else if (variable.getType() == Interpreter.ValueType.FLOAT) {
                value = readFloatInput();
            } else if (variable.getType() == Interpreter.ValueType.STRING) {
                value = readStringInput();
            }

            // Set the value in the interpreter passed as a parameter
            interpret.setVariable(varName, value);
        }
    }

    @Override//method for making an object to a string
    public String toString() {
        return "READ " + variables.toString();
    }

    // Example methods for reading input values
    private int readIntegerInput() {
        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter an integer: ");
        int inputValue = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        return inputValue;
    }

    private float readFloatInput() {
        //this method reads afloat input value
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter a float: ");
        float inputValue = scanner.nextFloat();
        scanner.nextLine(); 
        return inputValue;}

    private String readStringInput() {
        //This method reads a string input value
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter a string: ");
        String inputValue = scanner.nextLine();
        return inputValue; }
}
