import java.util.Stack;

public class ReturnNode extends StatementNode {
    private Stack<Integer> callStack = new Stack<>(); // Initialize callStack here 
    public ReturnNode(int lineNumber) {
        super(lineNumber);
    }
    @Override 
    public void evaluate() {
    	   if (!callStack.isEmpty()) {
        int returnLineNumber = callStack.pop(); //this evaluates the method and the cal stack is popepd
        int currentLineNumber = returnLineNumber; 
    } else {
        throw new RuntimeException("Return stack is empty");     // Handle the case when the call stack is empty
    }
}}
