import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.Stack;
import java.util.HashMap;
public class Interpreter {
	private static Interpreter instance;
	private boolean loop;
    private StatementNode currentStatement;
    private Stack<StatementNode> statementStack;
    private Queue<String> inputQueue = new LinkedList<>();
    private Queue<String> outputQueue = new LinkedList<>();
    private List<String> testInput = new LinkedList<>();
    private List<String> testOutput = new LinkedList<>();
    private boolean testMode = false;
	private static final String ADD = null;
	private static final String SUBTRACT = null;
	private static final String MULTIPLY = null;
	private static final String DIVIDE = null;
	//data structures are initialized
    LinkedList<Object> variableStorage; 
    private HashMap<String, LabeledStatementNode> labelMap;
    private HashMap<String, Integer> intVariables;
    private HashMap<String, Float> floatVariables;
    private HashMap<String, String> stringVariables;
    private TokenManager tokens; 
    public Interpreter() {//constructor functions to initialize data structures
    	floatVariables = new HashMap<>();
        stringVariables = new HashMap<>();
        variableStorage = new LinkedList<>();
        labelMap = new HashMap<>();
        intVariables = new HashMap<>();
           
    }
    public HashMap<String, LabeledStatementNode> getLabelMap() {
        return labelMap;
    }
    public static Interpreter getInstance() {
        if (instance == null) {
            instance = new Interpreter();
        }
        return instance;
    }
    public boolean isTestMode() {//this method  checks if the test mode is on
        return testMode;
    }

    public void toggleTestMode() { //this method toggles the test moide on
        testMode = !testMode;
        outputQueue.add("Test mode is now " + (testMode ? "ON" : "OFF"));
    }

    public void setInputQueue(Queue<String> inputQueue) {
        this.inputQueue = inputQueue;
    }

    public Queue<String> getOutputQueue() {
        return outputQueue;
    }

    public void setTestInput(List<String> testInput) {
        this.testInput = testInput;
    }

    public List<String> getTestOutput() {
        return testOutput;
    }

    public void clearOutputQueue() {
        outputQueue.clear();
    }

    public void input(String value) {
        if (testMode) {
            testInput.add(value);
        } else {
            inputQueue.add(value);
        }
    }
    public void print(String value) {
        if (testMode) {
            testOutput.add(value);
        } else {
            outputQueue.add(value);
        }
    }
    public void buildStatementLinkedList(StatementNode rootNode) {
        if (rootNode == null) {
            return;
        }
        StatementNode current = rootNode;
        StatementNode next = null;
        while (current != null) {// this Iterate over the statements
        	next = current.getNext(); // Assuming getNext() is the method to retrieve the next statement

            if (next != null) {
                current.setNext(next);}
            current = next;} }

   

//This processaes the statement node
public void preprocess(StatementNode rootNode) {
    for (StatementNode statement : rootNode.getStatements()) { // Assuming your AST supports iteration
        if (statement instanceof DataNode) {
            processDataNode((DataNode) statement);
        } else if (statement instanceof LabeledStatementNode) {
            processLabeledStatementNode((LabeledStatementNode) statement);
        } else {
            preprocess(statement); // This call is recursive forn the nested structures
        }
    }
}
private void processLabeledStatementNode(LabeledStatementNode labelNode) {
    String label = labelNode.getLabel();//this gets the labels

    if (!tokens.matchAndRemove(Token.TokenType.LABEL).isPresent()) { 
        throw new RuntimeException("Need an Expected a 'LABEL' token"); 
    } 

    if (labelMap.containsKey(label)) {
        throw new RuntimeException("you need to Duplicate label: " + label); 
    }
    labelMap.put(label, labelNode); 
    if (labelMap.containsKey(label)) {
        throw new RuntimeException("you need to Duplicate label: " + label); }
    labelMap.put(label, labelNode); }



    public enum ValueType {FLOAT ,INTEGER, STRING } // Assuming ValueType is an enum you've defined like this:

    private void processDataNode(DataNode dataNode) {
        for (Node valueNode : dataNode.getValues()) {
            ValueType type = (Interpreter.ValueType) valueNode.getType(); 

            if (type == ValueType.INTEGER) {
                int value = (int) valueNode.getType(); //  This Assumes getValue this returns an int 
                variableStorage.add(value); 
            } else if (type == ValueType.FLOAT) {
                float value = (float) valueNode.getType();  // This  Assumes getValue this  returns a float
                variableStorage.add(value); 
            } else if (type == ValueType.STRING) {
                String value = (String) valueNode.getType(); //Thus  Assumes  getValue  returns a String
                variableStorage.add(value); 
            } else {
                // Error Unsupported data type encountered
            	}}}
    public void execute(StatementNode rootNode) {
        if (rootNode == null) {
            return; // Handle potential null input
        }

        rootNode.evaluate(); // Call evaluate on the root node
    }
    // Methods for variable handling

    public void setVariable(String name, Object value) { //This method sets the variable's value
       if (value instanceof Integer) {
           intVariables.put(name, (Integer) value);
       } else if (value instanceof Float) {
           floatVariables.put(name, (Float) value);
       } else if (value instanceof String) {
           stringVariables.put(name, (String) value);
       } else {
           throw new RuntimeException("the Unsupported data type for variable: " + name);}}
    
    
    public Object getVariable(String name) {
        Object value = intVariables.get(name);  // Attempt to fetch from intVariables first
        if (value == null) {
            value = floatVariables.get(name); // Check floatVariables if not found
            if (value == null) {
                value = stringVariables.get(name); // Finally, check stringVariables
                if (value == null) {
                    throw new RuntimeException("Variable not found: " + name);
                }
            }
        }
        // Type Check and Return
        if (value instanceof Integer) {
            return (Integer) value; 
        } else if (value instanceof Float) {
            return (Float) value; 
        } else if (value instanceof String) {
            return (String) value; 
        } else {
            throw new RuntimeException("Unsupported data type stored in variable: " + name);
        }
    }

    public static int random(int min, int max) { //generates e arandom integer within range
        Random randomGenerator = new Random();
        return randomGenerator.nextInt(max - min + 1) + min;  
    }
    public static String LEFT$(String str, int count) { //this gets the left part of the string
        if (str == null || count <= 0) {
            return ""; // Handle empty string or non-positive count
        }
        return str.substring(0, Math.min(count, str.length())); // Ensure count doesn't exceed string length
    }
    public static String RIGHT$(String str, int count) {//This functions to get the right part of a string
        if (str == null || count <= 0) {
            return ""; // this Handle empty string or nonpositive count
        }
        return str.substring(Math.max(0, str.length() - count)); // Ensure count doesn't exceed string length
    }
    public static String MID$(String str, int start, int count) { //this functions to get the middle part of a string
        if (str == null || start <= 0 || count <= 0) {
            return ""; // Handle empty string, non-positive start/count
        }
        int endIndex = Math.min(start - 1 + count, str.length()); // Calculate adjusted end index
        return str.substring(start - 1, endIndex); // Use zero-based indexing for substring
    }//This function to covert a numeric value to a string
    public static String NUM$(Object value) {
        if (value instanceof Number) {
            return value.toString(); // Direct conversion if already numeric
        } else if (value instanceof String) {
            String stringValue = (String) value;
            try {
                // Attempt to parse as a double for broader flexibility
                double num = Double.parseDouble(stringValue);
                return String.valueOf(num);
            } catch (NumberFormatException e) {
                throw new RuntimeException("The numeric string for NUM$ conversion is not valid: " + value);
            }
        } else {
            throw new RuntimeException("This data type is unsupported for NUM$ conversion: " + value.getClass().getName());
        }
    }
    public static double VAL(String str) {//This functions to convert a string to a numeric value
        try {
            return Double.parseDouble(str); 
        } catch (NumberFormatException e) {
            throw new RuntimeException("This numeric string for VAL conversion is invalid: " + str);
        }
    }
    public static int VALPERCENT(String str) {//This function to convert a string to an integer value
        try {
            return Integer.parseInt(str); 
        } catch (NumberFormatException e) {
            // Include error handling here or adjust return type
            throw new RuntimeException("This integer string for VAL% conversion is invalid: " + str, e); }
    }

	public Object evaluateAndGetString(String string) {
		return null;
		
	}
	
	public Object interpret(Node node) {
	    loop = true;
	    StatementNode firstStatement = null;
	    currentStatement = firstStatement; // Assuming firstStatement is the entry point of the program
	    statementStack = new Stack<>();

	    while (loop && currentStatement != null) {
	        StatementNode nextStatement = currentStatement.getNext();
	        if (currentStatement instanceof EndNode) {
	            loop = false;
	        } else if (currentStatement instanceof IfNode) {
	            IfNode ifNode = (IfNode) currentStatement;
	            boolean condition = ifNode.getCondition().evaluate();
	            if (condition) {
	                // Go to the label indicated by the IfNode
	                String label = ifNode.getLabel();
	                currentStatement = labelMap.get(label);
	            }
	        } else if (currentStatement instanceof GosubNode) {
	            GosubNode gosubNode = (GosubNode) currentStatement;
	            // Push the next statement onto the stack
	            statementStack.push(nextStatement);// Go to the label indicated by the GosubNode
	            String label = gosubNode.getLabel();
	            currentStatement = labelMap.get(label);
	        } else if (currentStatement instanceof ReturnNode) {
	            currentStatement = statementStack.pop();//pop the nextfrom stack
	        } else if (currentStatement instanceof ForNode) {
	            ForNode forNode = (ForNode) currentStatement;
	            // Initialize loop variable
	            String loopVariable = forNode.getLoopVariable();
	            int initialValue = forNode.getInitialValue();
	            setVariable(loopVariable, initialValue);
	            // Move to the next statement
	            currentStatement = nextStatement;
	        } else if (currentStatement instanceof NextNode) {
	            NextNode nextNode = (NextNode) currentStatement;
	            // Update loop variable
	            String loopVariable = nextNode.getLoopVariable();
	            int currentValue = (int) getVariable(loopVariable);
	            int step = nextNode.getStep();
	            currentValue += step;
	            setVariable(loopVariable, currentValue);// Move to the next statement
	            int finalValue = nextNode.getFinalValue();
	            if (currentValue <= finalValue) {
	                // Go back to the corresponding FOR statement
	                currentStatement = labelMap.get(nextNode.getForLabel());
	            } else {
	                // Move to the next statement after the NEXT statement
	                currentStatement = nextStatement.getNext();
	            }
	        }
	        // Handle other types of statements similarly
	        else {
	         
	            currentStatement.evaluate();   // yyou have to execute the current statement
	        }
	        currentStatement = nextStatement;//ypu have to move next statement
	    }
	    return firstStatement;
	}

	public int evaluateInt(Node node) {
	    if (node instanceof IntegerNode) {
	        return (int) ((IntegerNode) node).getValue(); // Directly return value from IntNode
	    } else if (node instanceof VariableNode) {
	        String varName = ((VariableNode) node).getName();
	        Integer value = (Integer) getVariable(varName); // Fetch the integer value from the interpreter
	        if (value == null) {
	            throw new RuntimeException("Variable not found during integer evaluation: " + varName);
	        }
	        return value;
	    } else if (node instanceof MathOpNode) {
	        MathOpNode operatorNode = (MathOpNode) node;
	        int left = evaluateInt(operatorNode.getLeft()); // Recursively evaluate left operand
	        int right = evaluateInt(operatorNode.getRight()); // Recursively evaluate right operand


switch ((MathOpNode.getMathOp) operatorNode.getOperation()) {
	            case ADD:
	                return left + right;
	            case SUBTRACT:
	                return left - right;
	            case MULTIPLY:
	                return left * right;
	            case DIVIDE:
	                if (right == 0) {
	                    throw new RuntimeException("Division by zero encountered during integer evaluation");
	                }
	                return left / right;
	            default:
	                throw new RuntimeException("Unsupported operator for integer evaluation: " + operatorNode.getOpEnum());
	        }
	    } else {
	        throw new RuntimeException("Unsupported node type for integer evaluation: " + node.getClass().getName()); }}

	public float evaluateFloat(Node node) {
	    if (node instanceof FloatNode) {
	        return ((FloatNode) node).getValue(); // value is returned fromFloatNode
	    } else if (node instanceof VariableNode) {
	        String varName = ((VariableNode) node).getName();
	        Float value = (Float) getVariable(varName); // Fetch the float value from the interpreter
	        if (value == null) {
	            throw new RuntimeException("Variable not found during float evaluation: " + varName);
	        }
	        return value;
	    } else if (node instanceof MathOpNode) {
	        MathOpNode operatorNode = (MathOpNode) node;
	        // Cast operands to float for calculations to avoid integer overflow/truncation
	        float left = (float) evaluateInt(operatorNode.getLeft()); 
	        float right = (float) evaluateInt(operatorNode.getRight());
	        
	        switch ((MathOpNode.getMathOp) operatorNode.getOperation()) {
	            case ADD:
	                return left + right;
	            case SUBTRACT:
	                return left - right;
	            case MULTIPLY:
	                return left * right;
	            case DIVIDE:
	                if (right == 0) {
	                    throw new RuntimeException("Division by zero encountered during float evaluation");
	                }
	                return left / right;
	            default:
	                throw new RuntimeException("Unsupported operator for float evaluation: " + operatorNode.getOpEnum());
	        }
	    } else {
	        throw new RuntimeException("Unsupported node type for float evaluation: " + node.getClass().getName());
	    }
	}
	public Object evaluateString(Node node) {
	    if (node instanceof StringNode) {
	        return ((StringNode) node).getValue(); // Directly return value from StringNode
	    } else if (node instanceof VariableNode) {
	        String varName = ((VariableNode) node).getName();
	        Object value = getVariable(varName); // Fetch the variable's value
	        if (value == null) {
	            throw new RuntimeException("Variable not found during string evaluation: " + varName);
	        }

	        // a potential conversion happens possibly
	        if (value instanceof String) {
	            return value; // Already a string
	        } else {
	            throw new RuntimeException("Variable '" + varName + "' has incompatible type for string evaluation: " + value.getClass().getName());
	        }
	    } else if (node instanceof MathOpNode) { // this allows for concatenating
	        MathOpNode operatorNode = (MathOpNode) node;

	        // Evaluate left and right operands, potentially converting to strings
	        String leftValue = evaluateToString(operatorNode.getLeft());
	        String rightValue = evaluateToString(operatorNode.getRight());

	        if (operatorNode.getOperation() == MathOpNode.getMathOp.ADD) { // Concatenation
	            return leftValue + rightValue;
	        } else {
	            throw new RuntimeException("Unsupported operator for string concatenation: " + operatorNode.getOpEnum());
	        }
	    } else {
	        throw new RuntimeException("Unsupported node type for string evaluation: " + node.getClass().getName());
	    }
	}

	// Helper method for consistent string conversion (if applicable)
	private String evaluateToString(Node node) {
	    Object value = interpret(node); // Evaluate the node
	    if (value instanceof String) {
	        return (String) value; // this alreasy string
	    } else if (value instanceof Number) { // this is ap possible conversion to string
	        return value.toString(); //numnber is converted to string
	    } else {
	        throw new RuntimeException("This type is not compatible for string conversion during evaluation: " + value.getClass().getName()); }}
	 public static void setCurrentLineNumber(int lineNumber) {
	        int currentLineNumber = lineNumber;
	    }
	public void interpret(StatementNode ast) {
		// TODO Auto-generated method stub
		
	}}

