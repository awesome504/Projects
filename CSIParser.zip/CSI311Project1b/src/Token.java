

public class Token {//
    public enum TokenType {
        WORD, NUMBER, ENDOFLINE, PRINT, STRING, LABEL, LT, GT, EQUALS, NOTEQUALS, GREATEREQUAL, LESSEQUAL, READ, PLUS, TIMES, INTEGER, RIGHT_PAREN, LEFT_PAREN, FLOAT, MINUS, MULTIPLY, DIVIDE, LPAREN, RPAREN, DATA, COMMA, IF, ELSE, WHILE, FOR, STEP, IDENTIFIER, GOSUB, NEXT, RETURN, END,;

		
    }//the enum defines`many tokens

    private static TokenType type;//this is the token type
    private final String value; //gives a value for the token
    private final int lineNumber; //This shows the lion number of the token
    private final int charPosition;//The is the character position with the lines

    public Token(TokenType type, int lineNumber, int charPosition) {
        this(type, null, lineNumber, charPosition);
    }

    public Token(TokenType type, String value, int lineNumber, int charPosition) {//This method gets the type of token
        Token.type = type;
        this.lineNumber = lineNumber;
        this.charPosition = charPosition;
        this.value = value;
        ;
    }
    @Override
    public String toString() {//This method gets a rep of the token
        if (value != null) {
            return type + "(\"" + value + "\") at Line " + lineNumber + ", Position " + charPosition;
        } else {
            return type + " at Line " + lineNumber + ", Position " + charPosition;}}

	public static TokenType getTokenType() { //this method gets the specific tokentype
		return type;
	}
	
	public String getValue() {//Token value is returned
		return value;}}
