import java.text.ParseException;
import java.util.LinkedList;
import java.util.Optional;

public class Parser {//this class alows to for parsing arethemitic expression
	private static final String MINUS = null;//These are the constants for operator tokens
	private static final String PLUS = null;
	private static final String STRING = null;
	private static final String NUMBER = null;
	private final TokenManager tokens;
    private Node termz() {
        Node left = factorz();
        while (tokens.moreTokens()) {
            Token.TokenType type = tokens.peek().map(token -> Token.getTokenType()).orElse(null);
            if (type ==Token.TokenType.MULTIPLY || type == Token.TokenType.DIVIDE) {
                tokens.matchAndRemove(type);
                MathOpNode.getMathOp op = type == Token.TokenType.MULTIPLY ? MathOpNode.getMathOp.MULTIPLY : MathOpNode.getMathOp.DIVIDE;
                left = new MathOpNode(op, left, factorz());
            } else {
                return left;}} //there are no factors that will return the term
        return left;}
    public Parser(LinkedList<Token> tokens) {
        this.tokens = new TokenManager(tokens); //thies creates a token manager instance
    }

    public Node parse() {
        return expressionz(); // Start parsing with the expression method
    }
    private AssignNode assignmentz() {
        Optional<Token> variableToken = tokens.matchAndRemove(Token.TokenType.WORD);

        if (variableToken.isPresent() && tokens.matchAndRemove(Token.TokenType.EQUALS) != null) {//checks if a variable token is present if an equals tokens  is following it
            Node expression = expressionz();
            if (expression != null) {
                return new AssignNode(0, new VariableNode(variableToken.get().getValue()), expression, null, expression);} }

        return null; }//null is returned if fails

    private Node expressionz() {
        Node left = termz();
        while (tokens.moreTokens()) {
            switch (tokens.moreTokens() ? tokens.peek().map(token -> Token.getTokenType()).orElse(null) : null) {
                case PLUS:
                    tokens.matchAndRemove(Token.TokenType.PLUS);
                    left = new MathOpNode(MathOpNode.getMathOp.ADD, left, termz());
                    break;
                case MINUS:
                    tokens.matchAndRemove(Token.TokenType.MINUS);
                    left = new MathOpNode(MathOpNode.getMathOp.SUBTRACT, left, termz());
                    break;
                default:
                    return left;}}
        return left;}

    private ReadNode readz() {
        LinkedList<VariableNode> variables = new LinkedList<>();
        if (tokens.matchAndRemove(Token.TokenType.READ) == null) { //This makes sure that the read token is where it should be 
            return null; 
        } 
        do {
            Optional<Token> variableToken = tokens.matchAndRemove(Token.TokenType.WORD);//This makes sure that the read token is where it should be
            if (variableToken.isPresent()) {
                variables.add(new VariableNode(variableToken.get().getValue()));
            } else {
                return null; //This is for an error if the variable name is not there (there should be)
            }
        } while (tokens.matchAndRemove(Token.TokenType.COMMA) != null);

        return new ReadNode(0, variables); 
    }
    DataNode dataz() {
        LinkedList<Node> values = new LinkedList<>();
        if (tokens.matchAndRemove(Token.TokenType.DATA) == null) {// This allows for the data token to be there
            return null; 
        }
        do { //This do loop  parses the the comma seperated list
            tokens.peek().ifPresent(token -> { //checks to see if there is a token that needs some sort of processing
                Token.TokenType tokenType = token.getTokenType();

                switch (tokenType) {
                    case STRING: //goes through parser and adds string value
                        values.add(stringz()); 
                        break;
                    case NUMBER://goes through parser and add a numbers
                        values.add(factorz());
                        break;
                    default: 
                        return; //this is for errors
                }

            }); 
        } while (tokens.matchAndRemove(Token.TokenType.COMMA) != null);

        return new DataNode(0, values); //a data node is made which also incorperates parsed tokens
    }

    private InputNode inputz() {
        LinkedList<VariableNode> variables = new LinkedList<>();

        
        if (tokens.matchAndRemove(Token.TokenType.STRING) != null) {//the first value is tested whethere its a string or variable
            
        } else {// else makes sure that if it is a string , the token is overtaken and goes to th parsing values
            Optional<Token> variableToken = tokens.matchAndRemove(Token.TokenType.WORD);
            if (variableToken.isPresent()) {
                variables.add(new VariableNode(variableToken.get().getValue()));
            } else {
                return null; //this is for an error handling
            }
        }

        //the do loop parses the loop of variables
        do {
            Optional<Token> variableToken = tokens.matchAndRemove(Token.TokenType.WORD);
            if (variableToken.isPresent()) {
                variables.add(new VariableNode(variableToken.get().getValue()));
            } else {
                return null; // Error handling: Expected a variable 
            }
        } while (tokens.matchAndRemove(Token.TokenType.COMMA) != null);
        return new InputNode(0, null, variables, null);}

    private Node stringz() {
		return null;
	}
    private IfNode ifz() {
        if (tokens.matchAndRemove(Token.TokenType.IF) != null) {
            BooleanExpression condition = booleanExpressionz();
            StatementNode thenStatement = statement();

            // Optional 'else' clause
            if (tokens.matchAndRemove(Token.TokenType.ELSE) != null) {
                StatementNode elseStatement = statement();
                return new IfNode(condition, thenStatement, elseStatement);
            } else {
                return new IfNode(condition, thenStatement, null);  
            }
        }
        return null; // If the token wasn't 'IF', then it's not an IF statement
    }
    private FunctionCallNode functionInvocationz() {
        String functionName = tokens.matchAndRemove(null).get().getValue(); 
        tokens.matchAndRemove(Token.TokenType.LPAREN); // Match the opening parenthesis

        LinkedList<ExpressionNode> parameters = new LinkedList<>();
        if (!tokens.matchAndRemove(Token.TokenType.RPAREN).isPresent()) { 
            // Not an empty parameter list
            parameters.add((ExpressionNode) expressionz()); 

            while (tokens.matchAndRemove(Token.TokenType.COMMA) != null) {
                parameters.add((ExpressionNode) expressionz());
            }

            tokens.matchAndRemove(Token.TokenType.RPAREN);  // Match closing parenthesis
        } 

        return new FunctionCallNode(functionName, parameters); 
    }


  
    private StatementNode statement() {
        // ... Logic to handle labeled statements ...

        { // No label detected
            if (tokens.matchAndRemove(Token.TokenType.PRINT) != null) {
                return printz(); 
            }else if (tokens.matchAndRemove(Token.TokenType.GOSUB) !=null) {
                try {
					return gosubz();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }else if (tokens.matchAndRemove(Token.TokenType.READ) != null) {
                return readz();
             } else if (tokens.matchAndRemove(Token.TokenType.IF) != null) {
                return ifz(); 
            } else if (tokens.matchAndRemove(Token.TokenType.WHILE) != null) {
                return whilez(); // Assuming you have a whilez() method
            } else if (tokens.matchAndRemove(Token.TokenType.FOR) != null) {
                return forz();  // Assuming you have a forz() method
          
                // ... Call the relevant parsing methods ...
            } else {
                throw new RuntimeException("Unrecognized statement at line: "  /* ... */);
            }
        }
		return null;
    }
    private StatementNode gosubz() throws ParseException {
        if (tokens.matchAndRemove(Token.TokenType.GOSUB) != null) {
            Optional<Token> token = tokens.matchAndRemove(Token.TokenType.IDENTIFIER);

            if (token.isPresent()) { // Check if the token exists
                String targetLabel = token.get().getValue(); // Get the token and then its value
                GosubNode gosubNode = new GosubNode(0); 
                gosubNode.setTargetLabel(targetLabel);  
                return gosubNode; 
            } else {
                // Handle the case where the identifier is missing (e.g., throw an exception)
                throw new ParseException("Expected an identifier after GOSUB", 0); 
            }
        }
        return null;  
    }
    


  
	private ForNode forz() {
    	   if (tokens.matchAndRemove(Token.TokenType.FOR) != null) {
    	       AssignNode initialization = assignmentz(); 
    	       BooleanExpression condition = booleanExpressionz();
    	       Optional<Node> step = Optional.empty(); // Step is optional

    	       if (tokens.matchAndRemove(Token.TokenType.STEP) != null) {
    	           step = Optional.of(expressionz());
    	       }

    	       StatementNode body = statement();
    	       return new ForNode(initialization, condition, step, body);
    	   }
    	   return null; // Not a FOR loop
    	}
	

	
	private WhileNode whilez() {
		   if (tokens.matchAndRemove(Token.TokenType.WHILE) != null) {
		       BooleanExpression condition = booleanExpressionz();
		       StatementNode body = statement();
		       return new WhileNode(condition, body);
		   }
		   return null; // Not a WHILE loop
		}
	public BooleanExpression booleanExpressionz() {
	    Object operand1 = termz(); // Assuming 'term()' parses variables or literals
	    String operator = nextToken(); 
	    Object operand2 = termz(); 
	    return new BooleanExpression(operator, operand1, operand2);
	}
	private ReturnNode returnStatement() {
	    if (tokens.matchAndRemove(Token.TokenType.RETURN) != null) {
	        Node expression = expressionz(); // Parse the expression following the RETURN keyword
	        return new ReturnNode(0); // Return a new ReturnNode instance with the parsed expression
	    }
	    return null; // Return null if the next token is not RETURN
	}

	private String nextToken() {
		// TODO Auto-generated method stub
		return null;
	}
	private PrintNode printz() { 
	    if (tokens.matchAndRemove(Token.TokenType.PRINT) != null) {
	        LinkedList<Node> expressions = new LinkedList<>();

	        expressions.add(expressionz()); // Parse the first expression

	        while (tokens.matchAndRemove(Token.TokenType.COMMA) != null) {
	            expressions.add(expressionz()); // Parse subsequent expressions
	        }

	        return new PrintNode(0, expressions); 
	    } 

	    return null; // Not a print statement
	}
	private NextNode nextStatement() {
	    if (tokens.matchAndRemove(Token.TokenType.NEXT) != null) {
	        Optional<Token> variableToken = tokens.matchAndRemove(Token.TokenType.WORD);
	        if (variableToken.isPresent()) {
	            return new NextNode(0);
	        } else {
	            throw new RuntimeException("Expected variable after NEXT statement");
	        }
	    }
	    return null; // Return null if the next token is not NEXT
	}
	private EndNode endStatement() {
	    if (tokens.matchAndRemove(Token.TokenType.END) != null) {
	        return new EndNode(0); // Create and return an EndNode instance
	    }
	    return null; // Return null if the next token is not END
	}

	
	private Node factorz() {
        if (tokens.matchAndRemove(Token.TokenType.MINUS) != null) { //The unar minus token type
            return new MathOpNode(MathOpNode.getMathOp.MULTIPLY, new IntegerNode(-1), factorz());
        } if (!tokens.isEmpty() && tokens.peek().map(token -> Token.getTokenType()).orElse(null) == Token.TokenType.NUMBER) {  // The number token is handled en
            // Use matchAndRemove directly for clarity
            Optional<Token> numberToken = tokens.matchAndRemove(Token.TokenType.NUMBER);//thius determines the numbers

            Optional<String> result = Optional.of(numberToken.get().getValue());
            return result.isPresent() && result.get().contains(".") 
                    ? new FloatNode(Float.parseFloat(numberToken.get().getValue()))
                    : new IntegerNode(Integer.parseInt(numberToken.get().getValue()));
        } else if (tokens.matchAndRemove(Token.TokenType.LPAREN) != null) { // Handle nested expression
            Node expression = expressionz();//This is eror handling  and allows parentheses to close on the left side
           
            if (tokens.matchAndRemove(Token.TokenType.RPAREN) == null) {//This allows parentheses to close on the Right side
                throw new RuntimeException("The closing parentheses are not found");
            }
            return expression;
        } else {
            throw new RuntimeException("There is an unexpected token: " + tokens.peek().map(token -> Token.getTokenType()).orElse(null));//an error message is produced
            }}}

