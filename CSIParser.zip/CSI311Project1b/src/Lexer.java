import java.util.HashMap;
import java.util.LinkedList;

public class Lexer {

    private CodeHandler codeHandler;
    private LinkedList<Token> tokens;
    private int lineN;
    private int charPos;
    private HashMap<String, Token.TokenType> knownWords;
    private HashMap<String, Token.TokenType> twoCharSymbols;
    private HashMap<String, Token.TokenType> oneCharSymbols;

    public Lexer() {
        knownWords = new HashMap<>();
        knownWords.put("Print", Token.TokenType.PRINT);
        knownWords.put("Read", Token.TokenType.READ);
 


        twoCharSymbols = new HashMap<>();
        twoCharSymbols.put("<=", Token.TokenType.LESSEQUAL);
        twoCharSymbols.put(">=", Token.TokenType.GREATEREQUAL);
        twoCharSymbols.put("<>", Token.TokenType.NOTEQUALS);
        
       
        oneCharSymbols = new HashMap<>();
        oneCharSymbols.put("=", Token.TokenType.EQUALS);
        oneCharSymbols.put("<", Token.TokenType.LT);
        oneCharSymbols.put(">", Token.TokenType.GT);
       
    }

    public LinkedList<Token> lex(String filename) {
        codeHandler = new CodeHandler(filename);
        tokens = new LinkedList<>();
        lineN = 1;
        charPos = 1;

        while (!codeHandler.isDone()) {
            char currentChar = codeHandler.getChar();

            if (Character.isWhitespace(currentChar)) {
                handleWhitespace(currentChar);
            } else if (currentChar == '\n') {
                handleLineFeed();
            } else if (Character.isLetter(currentChar)) {
                processWord();
            } else if (Character.isDigit(currentChar)) {
                processNumber();
            } else {
                String twoCharSymbol = String.valueOf(currentChar) + codeHandler.look(0);
                if (twoCharSymbols.containsKey(twoCharSymbol)) {
                    tokens.add(new Token(twoCharSymbols.get(twoCharSymbol), lineN, charPos));
                    codeHandler.getChar(); // Consume the second character of the two-character symbol
                    charPos++;
                } else if (oneCharSymbols.containsKey(String.valueOf(currentChar))) {
                    tokens.add(new Token(oneCharSymbols.get(String.valueOf(currentChar)), lineN, charPos));
                } else if (currentChar == '"') {
                    processStringLiteral();
                } else if (currentChar == ':') {
                    processLabel();
                } else {
                    throw new RuntimeException("Unrecognized character: " + currentChar);
                }
            }
            charPos++;
        }

        return tokens;
    }

    private void handleWhitespace(char currentChar) {
        // Move past the whitespace character
        charPos++;
    }

    private void handleLineFeed() {
        tokens.add(new Token(Token.TokenType.ENDOFLINE, lineN, charPos));
        lineN++;
        charPos = 1;
    }
    private void processWord() {
        StringBuilder wordBuilder = new StringBuilder();
        wordBuilder.append(codeHandler.getChar());

        while (!codeHandler.isDone()) {
            char nextChar = codeHandler.look(0);
            if (Character.isLetterOrDigit(nextChar) || nextChar == '_') {
                wordBuilder.append(codeHandler.getChar());
            } else if (nextChar == '$' || nextChar == '%') {
                wordBuilder.append(codeHandler.getChar());
                break; 
            } else {
                break; 
            }
        }

        String word = wordBuilder.toString();

        // Refined tokenization
        if (knownWords.containsKey(word)) {
            tokens.add(new Token(knownWords.get(word), lineN, charPos)); 
        } else {
            tokens.add(new Token(Token.TokenType.IDENTIFIER, word, lineN, charPos)); 
        } 
    }

    private void processNumber() {
        // Implementation for processing numbers
    	StringBuilder numberBuilder = new StringBuilder();
        numberBuilder.append(codeHandler.getChar());
        boolean hasDecimalPoint = false;
        while (!codeHandler.isDone()) {//continues to build  number  until non digit number comes 
        char nextChar = codeHandler.look(0);
if (Character.isDigit(nextChar)) {
                numberBuilder.append(codeHandler.getChar());
             if (nextChar == '.' && !hasDecimalPoint) {
                numberBuilder.append(codeHandler.getChar());
                hasDecimalPoint = true;
            } else {
                break; }}
  tokens.add(new Token(Token.TokenType.NUMBER, numberBuilder.toString(), lineN, charPos));}}
    private void processComparisonOperator() {
        StringBuilder operatorBuilder = new StringBuilder(codeHandler.getChar());
        char nextChar = codeHandler.look(0);

        if (nextChar == '=') {
            operatorBuilder.append(codeHandler.getChar()); 
        }

        switch (operatorBuilder.toString()) {
            case ">=":
                tokens.add(new Token(Token.TokenType.GREATEREQUAL, lineN, charPos));
                break;
            case "<=":
                tokens.add(new Token(Token.TokenType.LESSEQUAL, lineN, charPos));
                break;
            case "=": // New case for EQUALS
                tokens.add(new Token(Token.TokenType.EQUALS, lineN, charPos));
                break;
            default:
        }}
    private void processStringLiteral() {
        StringBuilder stringBuilder = new StringBuilder();
        char currentChar = codeHandler.getChar(); // Consume the opening quote
        charPos++;

        while (currentChar != '"') {
            if (currentChar == '\\') {
                // Handle escape characters
                char nextChar = codeHandler.getChar();
                charPos++;
                switch (nextChar) {
                    case 'n':
                        stringBuilder.append('\n');
                        break;
                    case 't':
                        stringBuilder.append('\t');
                        break;
                    // Add handling for other escape characters if needed
                    default:
                        stringBuilder.append(nextChar);
                }
            } else {
                stringBuilder.append(currentChar);
            }
            currentChar = codeHandler.getChar();
            charPos++;
        }

        tokens.add(new Token(Token.TokenType.STRING, stringBuilder.toString(), lineN, charPos - stringBuilder.length() - 1));
        charPos++; // Consume the closing quote
    }

    private void processLabel() {
        StringBuilder labelBuilder = new StringBuilder();
        char currentChar = codeHandler.getChar(); // Consume the colon
        charPos++;

        while (Character.isLetterOrDigit(currentChar)) {
            labelBuilder.append(currentChar);
            currentChar = codeHandler.getChar();
            charPos++;
        }

        tokens.add(new Token(Token.TokenType.LABEL, labelBuilder.toString(), lineN, charPos - labelBuilder.length() - 1));
    }}