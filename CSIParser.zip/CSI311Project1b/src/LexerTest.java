import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import java.util.LinkedList;

public class LexerTest {

    @Test
    public void testProcessKeywordsAndSymbols() {
        String input = "Read x\nPrint \"Hello, World!\"\na <= b";
        String[] expectedTokens = {"READ", "WORD(x)", "ENDOFLINE", "PRINT", "STRING(\"Hello, World!\")", "ENDOFLINE", "WORD(a)", "LESSEQUAL", "WORD(b)", "ENDOFLINE"};

        Lexer lexer = new Lexer();
        LinkedList<Token> actualTokens = lexer.lex(input);

        assertArrayEquals(expectedTokens, actualTokens);
    }

    @Test
    public void testProcessNumbers() {
        String input = "123 45.67";
        String[] expectedTokens = {"NUMBER(123)", "NUMBER(45.67)", "ENDOFLINE"};

        Lexer lexer = new Lexer();
        LinkedList<Token> actualTokens = lexer.lex(input);

        assertArrayEquals(expectedTokens, actualTokens);
    }

    @Test
    public void testProcessStringLiteralsWithEscapeCharacters() {
        String input = "\"Escape characters: \\n\\t\\r\"";
        String[] expectedTokens = {"STRING(\"Escape characters: \\n\\t\\r\")", "ENDOFLINE"};

        Lexer lexer = new Lexer();
        String[] actualTokens = lexer.lex(input);

        assertArrayEquals(expectedTokens, actualTokens);
    }

    @Test
    public void testProcessLabels() {
        String input = "loop1: x = x + 1";
        String[] expectedTokens = {"LABEL(loop1)", "WORD(x)", "EQUALS", "WORD(x)", "PLUS", "NUMBER(1)", "ENDOFLINE"};

        Lexer lexer = new Lexer();
        String[] actualTokens = lexer.lex(input);

        assertArrayEquals(expectedTokens, actualTokens);
    }
}