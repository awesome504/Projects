import java.util.LinkedList;
import java.util.Optional;
public class TokenManager {
    private LinkedList<Token> tokenList;

    public TokenManager(LinkedList<Token> tokenList) {//manages token list
        this.tokenList = tokenList;
    }
    public Optional<Token> peek(int j) {//the token is looked at for specific index
        if (j >= 0 && j < tokenList.size()) {
            return Optional.of(tokenList.get(j));
        } else {
            return Optional.empty(); }
    }

    public boolean moreTokens() { //checks for more tokens
        return !tokenList.isEmpty();
    }

    public Optional<Token> matchAndRemove(Token.TokenType t) {//a token with a specified type is matched and removed
        if (moreTokens() && tokenList.getFirst().getTokenType() == t) {
            return Optional.of(tokenList.removeFirst());
        } else {
            return Optional.empty();//this returns an optional if index out bounbd
        }}

    public Optional<Token> peek() {
        if (!tokenList.isEmpty()) {
            return Optional.of(tokenList.getFirst()); //The first token is returned only if the list isnt empty
        } else {
            return Optional.empty(); //The empty optional returns if list isnt empty
            } }
    public boolean isEmpty() {
        return tokenList.isEmpty();//Returns if list is empty to be true
    }}