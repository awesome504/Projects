public class EndNode extends StatementNode {

    public EndNode(int lineNumber) {
		super(lineNumber);
	
	}

	@Override 
    public void evaluate() {
		System.exit(0);
        // Implementation for END statement execution 
    }
}
