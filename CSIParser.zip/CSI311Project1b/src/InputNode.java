import java.util.LinkedList;
import java.util.Scanner;

public class InputNode extends StatementNode {
    private final Node prompt; // Accepts either a string or variable
    private final LinkedList<VariableNode> variables;
    private final Interpreter interpreter; // Reference to the interpreter

    public InputNode(int lineNumber, Node prompt, LinkedList<VariableNode> vars, Interpreter interpreter) {
        super(lineNumber);
        this.prompt = prompt;
        this.variables = vars;
        this.interpreter = interpreter; }

    public Node getPrompt() {
        return prompt;
    }

    public LinkedList<VariableNode> getVariables() {
        return variables;
    }

    @Override
    public void evaluate() {
        // Print the prompt string if available
        if (prompt instanceof StringNode) {
            System.out.print(((StringNode) prompt).getValue() + " ");
        }

        // Read input values for each variable and assign them
        Scanner scanner = new Scanner(System.in);
        for (VariableNode variable : variables) {
            String input = scanner.nextLine();
            assignValueToVariable(variable, input);} }

    private void assignValueToVariable(VariableNode variable, String value) {
        interpreter.setVariable(variable.getName(), value);}
    @Override
    public String toString() {
        return "INPUT " + prompt + ", " + variables.toString();}
}

