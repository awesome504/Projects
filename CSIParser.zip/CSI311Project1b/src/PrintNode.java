import java.util.LinkedList;
import java.util.List;

public class PrintNode extends StatementNode {
    private final LinkedList<Node> expressions;

    public PrintNode(int lineNumber, LinkedList<Node> expressions) {
        super(lineNumber);
        this.expressions = expressions;
    }


	public LinkedList<Node> getExpressions() {
        return expressions;//getter for expressionlists
    }

    @Override
    public void evaluate() {
        // Iterate over each expression and print its value
        for (Node expression : expressions) {
            Object result = expression.evaluate(); // Evaluate the expression
            System.out.print(result.toString() + " "); // Print the result
        }
        System.out.println(); // Print a newline at the end
    }

    @Override
    public String toString() {
        return "Print: " + expressions.toString();
    }
}
