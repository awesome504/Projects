public interface visitor {
    void visitNextNode(NextNode nextNode);
    //return endnode in AST
    void visitEndNode(EndNode endNode);
    //returns ifnode in AST
    void visitIfNode(IfNode ifNode);
    //returns gosubnode inAST
    void visitGosubNode(GosubNode gosubNode);
    //visits returnode in AsT
    void visitReturnNode(ReturnNode returnNode);
   //visits for node in the AST
    void visitForNode(ForNode forNode);
}
//interface for all nodes next end if gosub return and for node