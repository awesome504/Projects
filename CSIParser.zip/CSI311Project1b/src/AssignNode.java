public class AssignNode extends StatementNode {
    private final Node valz;
    private VariableNode variable; // The variable being assigned to
    private Node expression;      // the expression is avalueted as well ass assigned
    private Interpreter interpreter; // This references the interpreter

    public AssignNode(int lineNumber, VariableNode variable, Node expression, Interpreter interpreter, Node value) {
        super(lineNumber);
        this.variable = variable;
        this.expression = expression;
        this.interpreter = interpreter;
        this.valz = value;}

    public int getAssignedValue() {
        // Extract the assigned value from the expression node
        Node expression = getExpression();
        if (expression instanceof IntegerNode) {
            return (int) ((IntegerNode) expression).getValue();
        } else {
            // Handle other cases if needed
            throw new RuntimeException("Assigned value is not an integer");
        }
    }


    public String getVariableName() {
        return variable.getName();
    }

    public Node getExpression() {
        return expression;
    }

    @Override
    public void evaluate() {
        // Evaluate the expression using the interpreter
        Object result = interpreter.interpret(expression);

        // Set the variable with the evaluated result
        if (valz instanceof IntegerNode && result instanceof Integer) {
            interpreter.setVariable(variable.getName(), (Integer) result);
        } else if (valz instanceof FloatNode && result instanceof Float) {
            interpreter.setVariable(variable.getName(), (Float) result);
        } else if (valz instanceof StringNode && result instanceof String) {
            interpreter.setVariable(variable.getName(), (String) result);
        } else {
            throw new RuntimeException("Unsupported type for assignment: " + result.getClass().getName());
        }
    }

    @Override
    public String toString() {
        return "Assign: " + variable.getName() + " = " + expression.toString();}
}


