import java.util.Optional;

public class ForNode extends StatementNode {
    private AssignNode initialization;
    private BooleanExpression condition;
    private Optional<Node> step;
    private StatementNode body;

    public ForNode(AssignNode initialization, BooleanExpression condition, Optional<Node> step, StatementNode body) {
        super(initialization.getLineNumber());  // Assuming you track line numbers
        this.initialization = initialization;
        this.condition = condition;
        this.step = step;
        this.body = body;
    }
    public AssignNode getInitialization() { return initialization; }
    public BooleanExpression getCondition() { return condition; }
    public Optional<Node> getStep() { return step; }
    public StatementNode getBody() { return body; }

    @Override
    public void evaluate() {
        initialization.evaluate();//initialization
        while (condition.evaluate()) { //this loops until the conditition
            body.evaluate(); //the body is looped 
            if (step.isPresent()) { //the step is performed is present
                performStep(initialization.getVariableName());   
            }
        } 
    }

    private void performStep(String loopVariable) {
        // Perform the step
        Interpreter interpreter = Interpreter.getInstance(); // Obtain an instance of Interpreter
        int currentValue = (int) interpreter.getVariable(loopVariable);
        int stepValue = (int) step.map(node -> {
            if (node instanceof IntegerNode) {
                return ((IntegerNode) node).getValue();
            } else {
                return 1; // this is the default step 
            }
        }).orElse(1); // If step is not present, default to 1
        interpreter.setVariable(loopVariable, currentValue + stepValue);
    }

    public String getLoopVariable() {
  // Extract the loop variable name from the initialization
        if (initialization instanceof AssignNode) {
            return ((AssignNode) initialization).getVariableName();
        }
        return null;
    }

    public int getInitialValue() {
        if (initialization instanceof AssignNode) {// Extract the initial value from the initialization
            return ((AssignNode) initialization).getAssignedValue();
        }
        return 0;
    }}