
public class VariableNode extends Node {//variable node class
    private final String name;//variable node is stored
    public VariableNode(String name) {
        this.name = name;}

    public String getName() {
        return name;} //the variable node name is retrived
        

    @Override  //to string method is overidenn and a string representation of the bvariable node
    public String toString() {
        return name;}}