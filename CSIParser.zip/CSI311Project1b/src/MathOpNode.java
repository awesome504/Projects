
public class MathOpNode extends Node {
    
    public enum getMathOp { ADD, SUBTRACT, MULTIPLY, DIVIDE }//This enum shows the math operations od dividion multiplication addition and subtra ction













	public static final String MathOp = null;











	

    private final getMathOp opx; // mathe opertation
    private final Node leftx; //for the left
    private final Node righty; // Right 
    

   
    public MathOpNode(getMathOp op, Node left, Node right) {//This constructor initializes math opertaors 
        this.opx = op; // Set the operation
        this.leftx = left; // set for the left
        this.righty = right; //setter for the right
    }
   
    @Override
    public String toString() {
        return null; // Placeholder for custom string representation (to be implemented)
    }
    public Object getOperation() {//this method gets the operation
        return opx; // the opertation returns
    }
    public Object getOpEnum() {//gets the enum
        return opx; // Return the operation
    }
    public Node getRight() {// Method retrieves the right operand
        return righty; // Return the right operand
    }

    public Node getLeft() {//left operand is retrieved
        return leftx; // Return the left operand
    }
    public Object performOperation(Object left, Object right) {
        // Ensure left and right operands are of the correct type
        if (!(left instanceof Integer) || !(right instanceof Integer)) {
            throw new IllegalArgumentException("Operands must be integers for performOperation");
        }
		return right;

	}}
