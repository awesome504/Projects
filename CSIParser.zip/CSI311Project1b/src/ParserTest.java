import org.junit.Test;
import static org.junit.Assert.*; // You'll need these imports

import java.util.LinkedList;

public class ParserTest {

    
	@Test
	public void testParseDataNode_mixedDataTypes() {
	    LinkedList<Token> tokens = new LinkedList<>();
	    tokens.add(new Token(Token.TokenType.DATA, "DATA", 0, 0));
	    tokens.add(new Token(Token.TokenType.STRING, "\"hello\"", 0, 0));
	    tokens.add(new Token(Token.TokenType.COMMA, ",", 0, 0));
	    tokens.add(new Token(Token.TokenType.NUMBER, "123", 0, 0));
	    tokens.add(new Token(Token.TokenType.COMMA, ",", 0, 0));
	    tokens.add(new Token(Token.TokenType.NUMBER, "3.14", 0, 0));  

	    LinkedList<Token> tokenManager = null;
	    Parser parser = new Parser(tokenManager); // Assuming you have a TokenManager set up

	    DataNode dataNode = parser.dataz();

	   
	    assertNotNull(dataNode);
	    assertEquals(3, dataNode.getValues().size()); 
	    assertTrue(dataNode.getValues().get(0) instanceof StringNode); 
	    assertTrue(dataNode.getValues().get(1) instanceof IntegerNode); 
	    assertTrue(dataNode.getValues().get(2) instanceof FloatNode);  
	    
	}}

